# Copyright notice:
"SvgToImage" Copyright Brahvim Bhaktvatsal 2022

Libraries this project uses: "Processing" and "UiBooster" 
use the GNU GPLv3 as their license.

Source for Processing: https://github.com/processing/processing
Source for UiBooster: https://github.com/milchreis/UiBooster

The "drop" Library uses the GNU LGPL 2.1 (and later) licenses.

Source for drop: http://transfluxus.github.io/drop/

Hence, this project too, makes use of the GNU GPLv3 license.

Kindly see the files, `COPYING` and `COPYING.LESSER` for these licenses.
Filename:            License:
`COPYING` ---------- GNU GPLv3
`COPYING.LESSER` --- GNU LGPL v2.1


# License notice:
SvgToImage is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, either
version 3 of the License, or (at your option) any later version.

SvgToImage is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with SvgToImage.
If not, see <https://www.gnu.org/licenses/>.
